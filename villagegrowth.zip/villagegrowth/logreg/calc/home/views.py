from django.shortcuts import render,redirect,HttpResponse
from django.conf import settings
import numpy
from . models import store
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pandas as pd
# Create your views here.
def home(request):
    return render(request,'home.html')
kil=2
def log(request):
    if request.method == 'POST':
        city2 = request.POST['city']

        c = int(city2)
        infrastructure1 = request.POST['infrastructure']

        amenities1 = request.POST['amenities']

        t = int(amenities1)
        village1 = request.POST['village']
        l = int(village1)
        d = int(infrastructure1)
        import pandas as pd
        from sklearn.linear_model import LinearRegression
        df = pd.read_csv("C:\\Users\\kittu\\OneDrive\\Desktop\\villagegrowth\\lin.csv")
        x = df[['city', 'infrastructure', 'village', 'amenities']]
        # this should be editeeded
        a3 = df.city
        b3 = df.infrastructure
        c3 = df.village
        d3 = df.amenities
        y = (5 * c3) + (b3 * 2) + (d3 * 5)+(a3* 5)+10
        print(y)

        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        data = LogisticRegression()
        data.fit(x_train, y_train)
        g = data.predict([[c,d, l, t]])
        h = int(g)
        p = data.predict(x_test)
        f = "The development of city is {}%  ".format(h)
        l = accuracy_score(y_test, p)
        v = ('{:.01f}%'.format(l * 100))
        k = "The accuracy is {}".format(v)
        x = f
        ni = store(city=city2, infrastructure=infrastructure1, village=village1, amenities=amenities1, fare=h)
        ni.save()
        print(x)
        return render(request, 'review.html', {'f': f})

def lin(request):
    if request.method == 'POST':
        city2 = request.POST['city']

        c = int(city2)
        infrastructure1 = request.POST['infrastructure']

        amenities1 = request.POST['amenities']

        t = int(amenities1)
        village1 = request.POST['village']
        l = int(village1)
        d = int(infrastructure1)
        import pandas as pd
        from sklearn.linear_model import LinearRegression
        df = pd.read_csv("C:\\Users\\kittu\\OneDrive\\Desktop\\villagegrowth\\lin.csv")
        x = df[['city', 'infrastructure', 'village', 'amenities']]
        # this should be editeeded
        a3 = df.city
        b3 = df.infrastructure
        c3 = df.village
        d3 = df.amenities
        y=(5 * c3) + (b3 * 2) + (d3 * 5)+(a3* 5)+15
        #y = (16) * (c3 / 2) + (b3 * 4) + (d3 * 3)+(a3*10)
        print(y)

        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        data = LogisticRegression()
        data.fit(x_train, y_train)
        g = data.predict([[c,d, l, t]])
        h = int(g)
        p = data.predict(x_test)
        f = "The development of city is {}%  ".format(h)
        l = accuracy_score(y_test, p)
        v = ('{:.01f}%'.format(l * 100))
        k = "The accuracy is {}".format(v)
        x = f
        ni = store(city=city2, infrastructure=infrastructure1, village=village1, amenities=amenities1, fare=h)
        ni.save()
        print(x)
        return render(request, 'review.html', {'f': f})
def dectree(request):
    if request.method == 'POST':
        city2 = request.POST['city']

        c = int(city2)
        infrastructure1 = request.POST['infrastructure']

        amenities1 = request.POST['amenities']

        t = int(amenities1)
        village1 = request.POST['village']
        l = int(village1)
        d = int(infrastructure1)
        import pandas as pd
        from sklearn.linear_model import LinearRegression
        df = pd.read_csv("C:\\Users\\kittu\\OneDrive\\Desktop\\villagegrowth\\lin.csv")
        x = df[['city', 'infrastructure', 'village', 'amenities']]
        y = 15
        a3 = df.city
        b3= df.infrastructure
        c3 = df.village
        d3 = df.amenities
        y=(5 * c3) + (b3 * 2) + (d3 * 5)+(a3* 5)+20
        #y = (18) * (c3 / 2) + (b3 * 4) + (d3 * 3)+(a3*10)
        print(y)

        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        data = DecisionTreeClassifier()
        data.fit(x_train, y_train)
        g = data.predict([[c, d, l, t]])
        h = int(g)
        p = data.predict(x_test)
        f = "The development of city is {}%    ".format(h)
        l = accuracy_score(y_test, p)
        v = ('{:.01f}%'.format(l * 100))
        k = "The accuracy is {}".format(v)
        x = f
        ni = store(city=city2, infrastructure=infrastructure1, village=village1, amenities=amenities1, fare=h)
        ni.save()
        print(x)
        return render(request, 'review.html', {'f': f})
def rating(request):
    return render(request,'rating.html')
def rate(request):
    if request.method=="POST":
        ans=request.POST['ans']
        cv=store(rating=ans)
        cv.save()
        return HttpResponse("thankyou for feedback")
