from django.db import models

# Create your models here.
class store(models.Model):
    infrastructure=models.CharField(blank=True,max_length=50)
    city = models.CharField(blank=True,max_length=50)
    village = models.IntegerField(default=1)
    amenities = models.CharField(blank=True,max_length=50)
    fare = models.IntegerField(default=1)
    rating=models.IntegerField(default=5)
    def __str__(self):
        return self.city
