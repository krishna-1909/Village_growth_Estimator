from django.contrib import admin
from . models import store
admin.site.register(store)
# Register your models here.
